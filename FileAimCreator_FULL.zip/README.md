# File Aim Creator

Android APK project.

## Chức năng
- Logo/icon neon
- Kích hoạt key 3 ngày
- Không hiển thị key trong màn hình Creator
- Tối đa 5 file/ngày
- Tên file
- Mật khẩu
- Chọn script
- Chọn extension
- Chọn file
- Nhập yêu cầu
- Tạo và lưu file thật qua Android Storage Access Framework

## Build
GitHub Actions nằm tại:
`.github/workflows/build-apk.yml`

Workflow build APK debug và đưa APK vào Artifacts.
