package com.fileaimcreator.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    static final String KEY = "PREMIUM-938448";
    static final long THREE_DAYS = 259200000L;
    static final int LIMIT = 5;
    static final int SAVE = 99;

    SharedPreferences sp;
    EditText key, name, password, request;
    Spinner script, ext;
    TextView quota;
    String output = "", outputName = "created.txt";

    int BG = Color.rgb(7,11,18);
    int PANEL = Color.rgb(16,24,39);
    int CYAN = Color.rgb(0,229,255);
    int WHITE = Color.WHITE;
    int MUTED = Color.rgb(155,167,184);

    public void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("data", MODE_PRIVATE);
        if (active()) creator(); else login();
    }

    boolean active() {
        long t = sp.getLong("active", 0);
        return t > 0 && System.currentTimeMillis() - t < THREE_DAYS;
    }

    int count() {
        String today = new SimpleDateFormat("yyyyMMdd", Locale.US).format(new Date());
        if (!today.equals(sp.getString("day",""))) {
            sp.edit().putString("day", today).putInt("count", 0).apply();
        }
        return sp.getInt("count", 0);
    }

    TextView tv(String s, float size, int color) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(size);
        v.setTextColor(color);
        v.setPadding(0,8,0,8);
        return v;
    }

    EditText input(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(MUTED);
        e.setTextColor(WHITE);
        e.setTextSize(16);
        e.setPadding(20,0,20,0);
        GradientDrawable g = new GradientDrawable();
        g.setColor(PANEL);
        g.setCornerRadius(18);
        g.setStroke(2, Color.rgb(30,70,90));
        e.setBackground(g);
        e.setLayoutParams(new LinearLayout.LayoutParams(-1,58));
        return e;
    }

    Button btn(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextSize(15);
        b.setTextColor(Color.BLACK);
        b.setAllCaps(false);
        b.setBackgroundColor(CYAN);
        b.setLayoutParams(new LinearLayout.LayoutParams(-1,58));
        return b;
    }

    LinearLayout box() {
        LinearLayout x = new LinearLayout(this);
        x.setOrientation(LinearLayout.VERTICAL);
        x.setPadding(22,18,22,28);
        x.setBackgroundColor(BG);
        return x;
    }

    void login() {
        LinearLayout x = box();
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.logo);
        x.addView(logo,new LinearLayout.LayoutParams(-1,180));

        TextView title = tv("FILE AIM CREATOR",28,CYAN);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        x.addView(title);

        TextView sub = tv("Kích hoạt để sử dụng Creator",16,MUTED);
        sub.setGravity(Gravity.CENTER);
        x.addView(sub);

        key = input("Nhập key");
        x.addView(key);

        Button go = btn("🔐  KÍCH HOẠT");
        go.setOnClickListener(v -> {
            if (KEY.equals(key.getText().toString().trim())) {
                sp.edit().putLong("active",System.currentTimeMillis()).apply();
                creator();
            } else key.setError("Key không hợp lệ");
        });
        x.addView(go);

        setContentView(x);
    }

    void creator() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout x = box();

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.logo);
        x.addView(logo,new LinearLayout.LayoutParams(-1,130));

        TextView title = tv("FILE AIM CREATOR",25,CYAN);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        x.addView(title);

        quota = tv("",14,MUTED);
        quota.setGravity(Gravity.CENTER);
        x.addView(quota);
        quota.setText("Đã tạo hôm nay: "+count()+"/"+LIMIT);

        name = input("Tên file");
        x.addView(name);

        password = input("Mật khẩu file");
        password.setInputType(0x81);
        x.addView(password);

        x.addView(tv("Chọn Script",15,WHITE));
        script = new Spinner(this);
        script.setAdapter(new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_dropdown_item,
                new String[]{"Script mặc định","Script Custom","Script Template"}));
        x.addView(script);

        x.addView(tv("Chọn Extension",15,WHITE));
        ext = new Spinner(this);
        ext.setAdapter(new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_dropdown_item,
                new String[]{".txt",".lua",".json",".cfg"}));
        x.addView(ext);

        Button choose = btn("📁  CHỌN FILE");
        choose.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.setType("*/*");
            i.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(i,10);
        });
        x.addView(choose);

        request = input("Yêu cầu muốn tạo");
        request.setSingleLine(false);
        request.setMinLines(4);
        x.addView(request);

        Button create = btn("⚡  CREATOR FILE");
        create.setOnClickListener(v -> create());
        x.addView(create);

        Button logout = btn("↻  ĐĂNG XUẤT");
        logout.setOnClickListener(v -> {
            sp.edit().remove("active").apply();
            login();
        });
        x.addView(logout);

        scroll.addView(x);
        setContentView(scroll);
    }

    void create() {
        if (!active()) { login(); return; }
        if (count() >= LIMIT) {
            new AlertDialog.Builder(this).setTitle("Đã hết lượt")
                    .setMessage("Đã đạt giới hạn 5 file hôm nay.")
                    .setPositiveButton("OK",null).show();
            return;
        }

        String n=name.getText().toString().trim();
        String r=request.getText().toString().trim();

        if(n.isEmpty()){name.setError("Nhập tên file");return;}
        if(password.getText().toString().isEmpty()){password.setError("Nhập mật khẩu");return;}
        if(r.isEmpty()){request.setError("Nhập yêu cầu");return;}

        String extension=ext.getSelectedItem().toString();
        if(!n.toLowerCase(Locale.US).endsWith(extension)) n+=extension;

        outputName=n;
        output =
            "FILE AIM CREATOR\n"+
            "================\n"+
            "Script: "+script.getSelectedItem()+"\n"+
            "Created: "+new Date()+"\n\n"+
            "REQUEST\n"+
            "-------\n"+r+"\n";

        sp.edit().putInt("count",count()+1).apply();
        quota.setText("Đã tạo hôm nay: "+count()+"/"+LIMIT);

        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_TITLE,outputName);
        startActivityForResult(i,SAVE);
    }

    protected void onActivityResult(int req,int result,Intent data) {
        super.onActivityResult(req,result,data);
        if(req==SAVE && result==RESULT_OK && data!=null) {
            try {
                OutputStream out=getContentResolver().openOutputStream(data.getData());
                out.write(output.getBytes(StandardCharsets.UTF_8));
                out.close();
                new AlertDialog.Builder(this).setTitle("Thành công")
                    .setMessage("File đã được lưu.")
                    .setPositiveButton("OK",null).show();
            } catch(Exception e) {
                new AlertDialog.Builder(this).setTitle("Lỗi")
                    .setMessage(e.getMessage())
                    .setPositiveButton("OK",null).show();
            }
        }
    }
}
