plugins {
    id("com.android.application")
}

android {
    namespace = "com.fileaimcreator.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.fileaimcreator.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 4
        versionName = "4.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
